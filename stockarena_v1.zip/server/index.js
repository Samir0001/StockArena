import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();
const app=express(); app.use(cors()); app.use(express.json());
const port=process.env.PORT||8787;
const demo={NVDA:{"price":null},AAPL:{"price":null},MSFT:{"price":null},GOOGL:{"price":null},AMZN:{"price":null}};
async function finnhub(symbol){
 if(!process.env.FINNHUB_API_KEY) return null;
 const r=await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${process.env.FINNHUB_API_KEY}`);
 if(!r.ok) return null; const d=await r.json();
 if(typeof d.c!=="number") return null;
 return {symbol,price:d.c,changePct:d.dp??null,source:"Finnhub"};
}
app.get("/api/health",(req,res)=>res.json({ok:true,service:"StockArena API"}));
app.get("/api/market/quote/:symbol",async(req,res)=>{
 const symbol=req.params.symbol.toUpperCase();
 try{const q=await finnhub(symbol); if(q)return res.json(q);}catch{}
 res.json({symbol,price:null,changePct:null,source:"No live provider configured"});
});
app.get("/api/baskets",(req,res)=>res.json([
 {id:"ai-infrastructure",name:"AI Infrastructure",weights:{NVDA:.30,MSFT:.25,GOOGL:.20,AMZN:.15,AMD:.10}},
 {id:"quality-growth",name:"Quality Growth",weights:{MSFT:.30,GOOGL:.25,AMZN:.25,NVDA:.20}}
]));
app.post("/api/social/thesis",(req,res)=>{
 const {wallet,symbol,text}=req.body||{};
 if(!wallet||!symbol||!text)return res.status(400).json({error:"wallet, symbol and text are required"});
 res.status(201).json({id:crypto.randomUUID(),wallet,symbol,text,createdAt:new Date().toISOString()});
});
app.listen(port,()=>console.log(`StockArena API running on http://localhost:${port}`));