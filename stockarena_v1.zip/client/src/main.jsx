import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API="http://localhost:8787";
const demoSeries=[174,171,176,173,181,178,184,182,188,186,191,189,195,193,199,197,203,201,207,205,211,209,216,214];

function Chart({data}){
  const max=Math.max(...data),min=Math.min(...data),w=900,h=300;
  const pts=data.map((v,i)=>`${(i/(data.length-1))*w},${h-25-((v-min)/(max-min||1))*(h-45)}`).join(" ");
  return <div className="chart"><svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none"><polyline points={pts} fill="none" stroke="var(--accent)" strokeWidth="4"/><line x1="0" y1="275" x2="900" y2="275" stroke="#263043"/></svg><span className="live">● LIVE DATA</span></div>
}
function App(){
 const [symbol,setSymbol]=useState("NVDA"),[quote,setQuote]=useState(null),[connected,setConnected]=useState(false),[tab,setTab]=useState("Discover");
 const [thesis,setThesis]=useState("");
 const [status,setStatus]=useState("Market adapter ready");
 useEffect(()=>{fetch(`${API}/api/market/quote/${symbol}`).then(r=>r.json()).then(setQuote).catch(()=>setQuote(null))},[symbol]);
 const price=quote?.price ?? null;
 const portfolios=useMemo(()=>[
  {name:"AI Infrastructure",owner:"Alex Labs",items:[["NVDA",30],["MSFT",25],["GOOGL",20],["AMZN",15],["AMD",10]]},
  {name:"Quality Growth",owner:"Maya Capital",items:[["MSFT",30],["GOOGL",25],["AMZN",25],["NVDA",20]]}
 ],[]);
 function connect(){setConnected(true);setStatus("Wallet UI connected (demo adapter)")}
 function action(x){setStatus(`${x} flow opened — production version requests live quote and wallet signature.`)}
 return <div className="app">
  <header><div className="brand">Stock<span>Arena</span><small>Solana Social Trading</small></div><button className="wallet" onClick={connect}>{connected?"Wallet Connected":"Connect Phantom"}</button></header>
  <nav>{["Discover","Portfolio","Social Feed","Baskets","Battles"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)}>{x}</button>)}</nav>
  <div className="layout">
   <main>
    <section className="card">
     <div className="muted">Reference market • {symbol}</div>
     <div className="ticker"><b>{symbol}</b><select value={symbol} onChange={e=>setSymbol(e.target.value)}><option>NVDA</option><option>AAPL</option><option>MSFT</option><option>GOOGL</option><option>AMZN</option></select></div>
     <div className="price">{price?`$${Number(price).toFixed(2)}`:"—"} <span className="green">{quote?.changePct!=null?`${quote.changePct.toFixed(2)}%`:"Live provider required"}</span></div>
     <Chart data={demoSeries}/>
     <div className="actions"><button className="buy" onClick={()=>action("Buy")}>Buy with USDC</button><button className="sell" onClick={()=>action("Sell")}>Sell</button></div>
     <p className="muted">{status}</p>
    </section>
    <section className="card">
      <div className="profile"><div className="avatar">AL</div><div><b>Alex Labs</b><div className="muted">Verified social strategy</div></div></div>
      <div className="thesis"><span className="pill">NVDA</span><span className="pill">30D</span><p><b>AI infrastructure thesis</b></p><p className="muted">Users can read the thesis, challenge it, or fork the allocation instead of blindly copying a trade.</p></div>
      <textarea placeholder="Write your own thesis..." value={thesis} onChange={e=>setThesis(e.target.value)}/>
      <div className="actions"><button onClick={()=>action("Follow")}>Follow</button><button onClick={()=>action("Fork Portfolio")}>Fork Portfolio</button><button onClick={()=>action("Challenge")}>Challenge</button></div>
    </section>
   </main>
   <aside>
    <section className="card"><h3>AI Trade Check</h3><p className="muted">Decision-support layer</p><div className="row"><span>Position limit</span><b>User defined</b></div><div className="row"><span>Market quote</span><b>{price?"Available":"Unavailable"}</b></div><button className="wide" onClick={()=>action("Trade Check")}>Challenge My Trade</button></section>
    <section className="card"><h3>Community Baskets</h3>{portfolios.map(p=><div className="basket"><b>{p.name}</b><small>{p.owner}</small><div>{p.items.map(i=><span className="pill">{i[0]} {i[1]}%</span>)}</div><button onClick={()=>action("Fork "+p.name)}>Fork →</button></div>)}</section>
   </aside>
  </div>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);